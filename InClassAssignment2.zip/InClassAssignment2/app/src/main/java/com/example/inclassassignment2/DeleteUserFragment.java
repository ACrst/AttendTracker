package com.example.inclassassignment2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class DeleteUserFragment extends Fragment {

    Button delete_user_button;
    EditText edittext_userid;


    public DeleteUserFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_delete_user, container, false);
        edittext_userid=view.findViewById(R.id.EditText_user_id);
        delete_user_button=view.findViewById(R.id.button_del);
//        del_info_header=view.findViewById(R.id.textView_header_delete);


        try {
            delete_user_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    int id = Integer.parseInt(edittext_userid.getText().toString());
                    System.out.println(id);
                    User user = new User();
                    user.setId(id);

                    MainActivity.myAppDatabase.myDao().deleteUser(user);

                    Toast.makeText(getActivity(), "User successfully removed", Toast.LENGTH_SHORT).show();
                    edittext_userid.setText("");
                }
            });
        }catch(Exception e){
            e.printStackTrace();
        }
        return view;
    }
}