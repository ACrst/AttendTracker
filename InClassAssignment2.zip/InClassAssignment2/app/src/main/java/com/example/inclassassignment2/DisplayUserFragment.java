package com.example.inclassassignment2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;


public class DisplayUserFragment extends Fragment {

    TextView txtinfo,textheader;

    public DisplayUserFragment() {
        // Required empty public constructor
    }




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_display_user, container, false);
        txtinfo=view.findViewById(R.id.textView_info_user);
        textheader=view.findViewById(R.id.textView_headeruserinfo);
        List<User> users=MainActivity.myAppDatabase.myDao().getUsers();
        textheader.setText("User Information details");
        String info="";
        for(User usr:users)
        {
            int id=usr.getId();
            String fname=usr.getFirstName();
            String lname=usr.getLastName();
            info=info +"\n\n"+"UserID:"+id+"\nFirst Name:"+fname +"\n"+"Last Name:"+lname;
        }

        txtinfo.setText(info);
        return view;
    }


}