package com.example.inclassassignment2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.w3c.dom.Text;


public class InsertUserFragment extends Fragment implements View.OnClickListener {

    Button SaveAddedUser;
    EditText editFirstName,editLastName, edituserid;
    Text InsertUserInfo;

    public InsertUserFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_insert_user, container, false);
        SaveAddedUser=view.findViewById(R.id.save_button);
        edituserid=view.findViewById(R.id.EditText_user_id);
        editFirstName=view.findViewById(R.id.editText_FirstName);
        editLastName=view.findViewById(R.id.editText_LastName);
        SaveAddedUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id=Integer.parseInt(edituserid.getText().toString());
                String FirstName=editFirstName.getText().toString();
                String LastName=editLastName.getText().toString();

                User user=new User();
                user.setId(id);
                user.setFirstName(FirstName);
                user.setLastName(LastName);
                MainActivity.myAppDatabase.myDao().addUser(user);
                Toast.makeText(getActivity(),"User Added successfully",Toast.LENGTH_SHORT).show();

                editFirstName.setText("");
                editLastName.setText("");
                edituserid.setText("");
            }
        });

        return view;
    }

    @Override
    public void onClick(View v) {
        switch(v.getId())
        {
            case R.id.save_button:
                MainActivity.fragmentManager.beginTransaction().replace(R.id.fragment_container,new InsertUserFragment()).addToBackStack(null).commit();
                break;
        }
    }
}